
from logic import apply_confidence_gate
from dummy_text_data import dummy_data

count = 0

for item in dummy_data:
    result = apply_confidence_gate(item["keyword"], item["confidence"])
    print(result)
    
    if result["status"] == "VALID":
        count += 1

print("Total Alerts:", count)