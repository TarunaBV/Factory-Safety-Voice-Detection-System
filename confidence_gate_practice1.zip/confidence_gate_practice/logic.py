
from config import THRESHOLD

def apply_confidence_gate(keyword, confidence):
    if confidence >= THRESHOLD:
        return {
            "keyword": keyword,
            "confidence": confidence,
            "status": "VALID"
        }
    else:
        return {
            "keyword": keyword,
            "confidence": confidence,
            "status": "IGNORE"
        }
