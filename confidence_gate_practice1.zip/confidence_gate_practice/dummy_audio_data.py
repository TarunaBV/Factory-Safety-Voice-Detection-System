dummy_audio_predictions = [
    {"file": "audio1.wav", "label": "help", "score": 0.91},
    {"file": "audio2.wav", "label": "noise", "score": 0.40},
    {"file": "audio3.wav", "label": "emergency", "score": 0.87},
    {"file": "audio4.wav", "label": "random", "score": 0.60},
]