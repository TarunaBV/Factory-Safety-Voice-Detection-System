from transformers import pipeline
from logic import apply_confidence_gate

pipe = pipeline("automatic-speech-recognition")

audio_file = "sample.wav"

result = pipe(audio_file)

text = result["text"]
confidence = 0.90  # dummy

final_result = apply_confidence_gate(text, confidence)

print("Model Output:", text)
print("Confidence:", confidence)
print("Final Decision:", final_result)
from transformers import pipeline
from logic import apply_confidence_gate

# Load speech recognition model
pipe = pipeline("automatic-speech-recognition")

# List of audio files
audio_files = ["sample.wav", "sample2.wav"]

print("---- AUDIO TEST START ----\n")

for file in audio_files:
    try:
        # Run model
        result = pipe(file)

        text = result["text"]
        
        # Dummy confidence (since wav2vec2 does not give confidence directly)
        confidence = 0.90  

        # Apply your logic
        final_result = apply_confidence_gate(text, confidence)

        print(f"File: {file}")
        print(f"Model Output: {text}")
        print(f"Confidence: {confidence}")
        print(f"Final Decision: {final_result}")
        print("--------\n")

    except Exception as e:
        print(f"Error processing {file}: {e}")

