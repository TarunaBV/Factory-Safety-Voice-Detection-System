
from logic import apply_confidence_gate
from dummy_audio_data import dummy_audio_predictions

count = 0

for item in dummy_audio_predictions:
    result = apply_confidence_gate(item["label"], item["score"])
    
    print(item["file"], "→", result)
    
    if result["status"] == "VALID":
        count += 1

print("Total Audio Alerts:", count)