dummy_data = [
    {"keyword": "help", "confidence": 0.92},
    {"keyword": "emergency", "confidence": 0.88},
    {"keyword": "stop", "confidence": 0.83},
    {"keyword": "noise", "confidence": 0.45},
    {"keyword": "machine sound", "confidence": 0.30},
]